import { View, Text, StyleSheet, Image, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';

export default function HomeScreen() {
  const categories = [
    { id: '1', name: 'Photos', icon: 'images-outline', count: 485 },
    { id: '2', name: 'Videos', icon: 'videocam-outline', count: 32 },
    { id: '3', name: 'Audio', icon: 'musical-notes-outline', count: 55 },
    { id: '4', name: 'Documents', icon: 'document-text-outline', count: 120 },
  ];

  const recentFiles = [
    {
      id: '1',
      name: 'Summer Vacation.jpg',
      date: '2 hours ago',
      size: '4.8 MB',
      thumbnail: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e',
    },
    {
      id: '2',
      name: 'Project Presentation.pdf',
      date: 'Yesterday',
      size: '2.3 MB',
      thumbnail: 'https://images.unsplash.com/photo-1586281380349-632531db7ed4',
    },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>Welcome back</Text>
            <Text style={styles.username}>John Doe</Text>
          </View>
          <TouchableOpacity style={styles.profileButton}>
            <Image
              source={{ uri: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e' }}
              style={styles.profileImage}
            />
          </TouchableOpacity>
        </View>

        <View style={styles.searchContainer}>
          <View style={styles.searchBar}>
            <Ionicons name="search" size={20} color="#94A3B8" />
            <Text style={styles.searchPlaceholder}>Search files...</Text>
          </View>
        </View>

        <View style={styles.categoriesContainer}>
          <Text style={styles.sectionTitle}>Categories</Text>
          <View style={styles.categoriesGrid}>
            {categories.map((category) => (
              <TouchableOpacity key={category.id} style={styles.categoryCard}>
                <View style={styles.categoryIcon}>
                  <Ionicons name={category.icon} size={24} color="#6366F1" />
                </View>
                <Text style={styles.categoryName}>{category.name}</Text>
                <Text style={styles.categoryCount}>{category.count} files</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        <View style={styles.recentContainer}>
          <View style={styles.recentHeader}>
            <Text style={styles.sectionTitle}>Recent Files</Text>
            <TouchableOpacity>
              <Text style={styles.seeAllButton}>See all</Text>
            </TouchableOpacity>
          </View>
          {recentFiles.map((file) => (
            <TouchableOpacity key={file.id} style={styles.fileCard}>
              <Image source={{ uri: file.thumbnail }} style={styles.fileThumbnail} />
              <View style={styles.fileInfo}>
                <Text style={styles.fileName}>{file.name}</Text>
                <View style={styles.fileMetadata}>
                  <Text style={styles.fileDate}>{file.date}</Text>
                  <Text style={styles.fileDot}>•</Text>
                  <Text style={styles.fileSize}>{file.size}</Text>
                </View>
              </View>
              <TouchableOpacity style={styles.fileMoreButton}>
                <Ionicons name="ellipsis-vertical" size={20} color="#94A3B8" />
              </TouchableOpacity>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
  },
  greeting: {
    fontSize: 14,
    color: '#64748B',
  },
  username: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0F172A',
    marginTop: 4,
  },
  profileButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    overflow: 'hidden',
  },
  profileImage: {
    width: '100%',
    height: '100%',
  },
  searchContainer: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  searchPlaceholder: {
    marginLeft: 8,
    color: '#94A3B8',
    fontSize: 16,
  },
  categoriesContainer: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0F172A',
    marginBottom: 16,
  },
  categoriesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginHorizontal: -6,
  },
  categoryCard: {
    width: '50%',
    padding: 6,
  },
  categoryIcon: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: '#EEF2FF',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  categoryName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0F172A',
    marginBottom: 4,
  },
  categoryCount: {
    fontSize: 14,
    color: '#64748B',
  },
  recentContainer: {
    paddingHorizontal: 20,
  },
  recentHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  seeAllButton: {
    fontSize: 14,
    fontWeight: '600',
    color: '#6366F1',
  },
  fileCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 12,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  fileThumbnail: {
    width: 48,
    height: 48,
    borderRadius: 8,
  },
  fileInfo: {
    flex: 1,
    marginLeft: 12,
  },
  fileName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0F172A',
    marginBottom: 4,
  },
  fileMetadata: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  fileDate: {
    fontSize: 14,
    color: '#64748B',
  },
  fileDot: {
    fontSize: 14,
    color: '#64748B',
    marginHorizontal: 6,
  },
  fileSize: {
    fontSize: 14,
    color: '#64748B',
  },
  fileMoreButton: {
    padding: 4,
  },
});